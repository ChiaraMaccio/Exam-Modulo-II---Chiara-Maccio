CREATE DATABASE toysgroup;


CREATE TABLE product (
    id_product INT AUTO_INCREMENT UNIQUE NOT NULL PRIMARY KEY,
    nome_prod VARCHAR(50) NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    prezzo_unit DECIMAL(10 , 2 ) NOT NULL
);

INSERT INTO product (nome_prod, categoria, prezzo_unit)
VALUES 
('Barbie','Bambole','7.50'),
('Macchinina', 'Modellini', '4.70'),
('Peluches', 'Bambole', '5.10'),
('Album_figurine', 'Action_figure', '8.30'),
('Lego', 'Manuali', '17.20'),
('Kit_cucina', 'Role_play','26.10'),
('Puzzle', 'Manuali', '11.50'),
('Costruzioni', 'Manuali', '13.90'),
('Dinosauri', 'Modellini', '6.50'),
('Play_Doh', 'Manuali', '9.20')
;


CREATE TABLE sales (
    id_sales INT AUTO_INCREMENT UNIQUE NOT NULL PRIMARY KEY,
    id_product INT,
    id_region INT,
    quantita INT,
    data_ordine DATE,
    FOREIGN KEY (id_product)
        REFERENCES product (id_product),
    FOREIGN KEY (id_region)
        REFERENCES region (id_region)
);

INSERT INTO sales (id_product, id_region, quantita, data_ordine)
VALUES
(5, 15, 3, '2021-03-12'),
(9,	12,	5, '2021-05-07'),
(10, 6,	2, '2022-02-01'),
(1,	9, 4, '2022-07-03'),
(7,	8, 2, '2022-09-24'),
(3,	6, 5, '2022-11-17'),
(10, 20, 3,	'2023-01-18'),
(8,	16,	5, '2023-07-01'),
(2,	7, 4, '2023-10-07'),
(6,	14,	1, '2024-02-22')
;


CREATE TABLE region (
    id_region INT AUTO_INCREMENT UNIQUE NOT NULL PRIMARY KEY,
    nome_regione TEXT NOT NULL,
    area_geografica VARCHAR(50) NOT NULL
);

INSERT INTO region (nome_regione, area_geografica)
VALUES
('Abruzzo',	'Sud'),
('Basilicata', 'Sud'),
('Calabria', 'Sud'),
('Campania', 'Sud'),
('Emilia-Romagna', 'Nord-est'),
('Friuli-Venezia-Giulia', 'Nord-est'),
('Lazio', 'Centro'),
('Liguria',	'Nord-ovest'),
('Lombardia', 'Nord-ovest'),
('Marche', 'Centro'),
('Molise', 'Sud'),
('Piemonte', 'Nord-ovest'),
( 'Puglia',	'Sud'),
('Sardegna', 'Isole'),
('Sicilia',	'Isole'),
('Toscana',	'Centro'),
('Trentino-Alto-Adige',	'Nord-est'),
(' Umbria',	'Centro'),
("Val-d'Aosta",	'Nord-ovest'),
('Veneto', 'Nord-est')
;



---- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno ----

SELECT 
p.id_product,
p.nome_prod,
    YEAR(s.data_ordine) AS year_ordine,
    SUM(s.quantita * p.prezzo_unit) AS fatturato_tot
FROM
    sales AS s
        INNER JOIN
    product AS p ON s.id_product = p.id_product
GROUP BY year_ordine, p.id_product;



---- Esporre il fatturato totale per regione per anno. Ordina il risultato per data e per fatturato decrescente. ----

SELECT 
    r.nome_regione,
    YEAR(s.data_ordine) AS year_ordine,
    SUM(s.quantita * p.prezzo_unit) AS fatturato_tot
FROM
    sales AS s
        INNER JOIN
    product AS p ON s.id_product = p.id_product
        INNER JOIN
    region AS r ON s.id_region = r.id_region
GROUP BY r.nome_regione , year_ordine
ORDER BY year_ordine DESC , fatturato_tot DESC;


---- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? ---

SELECT 
    p.categoria, SUM(s.quantita) AS N_quantity
FROM
    sales AS s
        JOIN
    product AS p ON s.id_product = p.id_product
GROUP BY p.categoria
ORDER BY N_quantity DESC
LIMIT 1;


--- Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. -------

SELECT 
    p.id_product, p.nome_prod, s.id_sales
FROM
    product AS p
        LEFT JOIN
    sales AS s ON p.id_product = s.id_product
WHERE
    s.id_sales IS NULL;

--- secondo metodo ---

SELECT 
    *
FROM
    product AS p
WHERE
    p.id_product NOT IN (SELECT 
            s.id_product
        FROM
            sales AS s);
            
            
------ Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente) -----

SELECT 
    p.id_product, p.nome_prod, max(s.data_ordine) as Latest_Order
FROM
    product AS p
        JOIN
    sales AS s ON p.id_product = s.id_product
    GROUP BY p.id_product, p.nome_prod
ORDER BY Latest_Order DESC
;
